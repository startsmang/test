$(function () {
    //设置部门值的回显
//            console.log($(":input[name='department.id'] option[value='3']"));
    $(":input[name='department.id'] option[value='${employee.department.id}']").prop("selected",true);
    //设置超级管理员的回显
    // console.log($(":checkbox[name=admin]"));


    //做表单校验
    $("#editForm").validate({
        rules:{
            name:{
                required:true,
                minlength:2
            },
            password:{
                required:true,
                minlength:2
            },
            repassword:{
                equalTo:"#password"
            },
            email:{
                email:true
            },
            age:{
                range:[18,60]
            }
        },
        messages:{
            name:{
                required:"用户名必填",
                minlength:"最小长度为2"
            },
            password:{
                required:"密码必填",
                minlength:"最小长度为2"
            },
            repassword:{
                equalTo:"两次密码不一致"
            },
            email:{
                email:"邮箱格式不正确"
            },
            age:{
                range:"年龄必须在{0}-{1}之间"
            }
        }
    });
    //==========================================================================
    //列表移动
    $("#selectAll").click(function () {
        moveAll(".roleAll",".roleSelect");
    });
    $("#deselectAll").click(function () {
        moveAll(".roleSelect",".roleAll");
    });
    $("#select").click(function () {
        moveSelect(".roleAll",".roleSelect");
    });
    $("#deselect").click(function () {
        moveSelect(".roleSelect",".roleAll");
    });
    //列表选择去重
    var ids=[];
    //找到已选泽的
    $.each($(".roleSelect option"),function (index,item) {
        ids[index]= $(item).val();
    })
    console.log(ids);
    //遍历所有的权限项目
    $.each($(".roleAll option"),function (index,item) {
        if($.inArray($(item).val(),ids)>-1){//在ids集合中可以找到
            $(item).remove();//删除自己
        }
    })
    //==========================================================================
})