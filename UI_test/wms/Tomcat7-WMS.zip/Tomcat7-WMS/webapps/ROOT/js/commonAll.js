//禁用添加参数的时候拼接[] 的功能
jQuery.ajaxSettings.traditional = true;
/** table鼠标悬停换色* */
$(function() {
	// 如果鼠标移到行上时，执行函数
	$(".table tr").mouseover(function() {
		$(this).css({background : "#CDDAEB"});
		$(this).children('td').each(function(index, ele){
			$(ele).css({color: "#1D1E21"});
		});
	}).mouseout(function() {
		$(this).css({background : "#FFF"});
		$(this).children('td').each(function(index, ele){
			$(ele).css({color: "#909090"});
		});
	});
	//===============================删除操作代码===============================================
    //删除操作
    $(".btn_delete").click(function () {
        //0 获取需要删除的url地址
        var  deleteUrl=$(this).data("url");
        //1 弹出确认对话框
        showDialog("亲,确定要删除吗?",function () {
            //发送ajax请求
            $.get(deleteUrl,function (data) {
                if(data.success){
                    showDialog("删除成功",function () {
                        window.location.reload();
                    })
                }else{
                    showDialog(data.msg);
                }
            });
        },true)
    })
	//===============================删除代码===============================================
	//===============================新增操作代码===============================================
    //新增操作
    $(".btn_input").click(function () {
        window.location.href = $(this).data("url");
    });
	//===============================新增操作代码===============================================
});

//列表移动操作
//=============================================================================
//全部移动
function moveAll(src,tartget){
    $(src+" option").appendTo($(tartget))
}
//选择移动
function moveSelect(src,tartget) {
    $(src+" option:selected").appendTo($(tartget))
}
//=============================================================================

//弹出对话框的方法
/**
 * title: 标题
 * content: 显示内容
 * ok: fn,true 确定按钮的操作
 * cancel: fn,true,false 取消按钮的操作
 */
function showDialog(content,ok,cancel){
    $.dialog({
        title:'温馨提示',
        content:content,
        lock:true,
        ok:ok||true,
        cancel:cancel||false
    })
}

//============================批量删除=====================================
$(function () {
    $(".btn_batchDelete").click(function () {
        var deleteUrl = $(this).data("url");
        showDialog("亲,确定要批量删除吗?",function () {
            // console.log($(".acb:checked"));
            var ids=[];
            $.each($(".acb:checked"),function (index, item) {
                ids[index]=$(item).data("oid");
            });
            if(ids.length==0){
                showDialog("请选择需要删除的记录");
                return ;
            }
            //1 发送ajax 批量删除请求
            $.get(deleteUrl,{"ids":ids},function (data) {
                if(data.success){
                    showDialog("删除成功",function () {
                        window.location.reload();
                    })
                }
            })
        },true);
    });
    //在页面加载完毕的时候去掉勾勾
    $(":checkbox").prop("checked",false);
    //表头复选框的值改变事件
    $("#all").change(function () {
        var checked=$(this).prop("checked");
        $(":checkbox").prop("checked",checked);
    });
})
//=================================================================
